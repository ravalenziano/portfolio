Controls:
Move - Arrow Keys
Accelerate - x
Shoot - y

To start game - Right Click, New Game
